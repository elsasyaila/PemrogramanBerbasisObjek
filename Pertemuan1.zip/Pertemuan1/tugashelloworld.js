// Menampilkan Hello World di console
console.log("Hello World!");