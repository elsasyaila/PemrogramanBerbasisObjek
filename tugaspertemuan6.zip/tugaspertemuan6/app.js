const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Simpan data di memori untuk kesederhanaan
let anggotaList = [
    { id: 1, nama: 'John Doe', nim: '12345', angkatan: 2020, prodi: 'Informatika', noHp: '081234567890' },
    { id: 2, nama: 'Jane Smith', nim: '67890', angkatan: 2019, prodi: 'Sistem Informasi', noHp: '089876543210' }
];

app.get('/', (req, res) => {
    res.render('index', { anggotaList });
});

app.get('/tambah', (req, res) => {
    res.render('form', { anggota: {}, action: '/tambah' });
});

app.post('/tambah', (req, res) => {
    const newAnggota = {
        id: anggotaList.length + 1,
        ...req.body
    };
    anggotaList.push(newAnggota);
    res.redirect('/');
});

app.get('/edit/:id', (req, res) => {
    const anggota = anggotaList.find(a => a.id == req.params.id);
    res.render('form', { anggota, action: `/edit/${req.params.id}` });
});

app.post('/edit/:id', (req, res) => {
    const index = anggotaList.findIndex(a => a.id == req.params.id);
    anggotaList[index] = {...anggotaList[index], ...req.body };
    res.redirect('/');
});

app.get('/hapus/:id', (req, res) => {
    anggotaList = anggotaList.filter(a => a.id != req.params.id);
    res.redirect('/');
});

app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});